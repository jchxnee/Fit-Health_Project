package com.fithealth.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FithealthBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
